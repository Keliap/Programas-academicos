#include<stdlib.h>
#include<iostream>
#include<string.h>

typedef struct tipocelula{
	int chave;
	struct tipocelula * prox;
};

typedef struct tipofila{
	struct tipocelula *frente, * tras;
};

void ffvazia(struct tipofila *fila){
	fila->frente = (struct tipocelula *)
	malloc(sizeof(struct tipocelula));
	fila->tras = fila->frente;
	fila->frente->prox = NULL;
}

int vazia(struct tipofila fila){
	return(fila.frente == fila.tras);
}

void enfileira(int x, struct tipofila *fila){
	fila->tras->prox = (struct tipocelula *)
		malloc(sizeof(struct tipocelula));
	fila->tras = fila->tras->prox;
	fila->tras->chave = x;
	fila->tras->prox = NULL;
}

void desinfileira(struct tipofila *fila, struct tipocelula *celula){
	struct tipocelula *q;
	if(vazia(*fila)){
		printf("Erro fila fila esta vazia\n");
		return;
	}
	q = fila->frente;
	fila->frente = fila->frente->prox;
	celula->chave = fila->frente->chave;
	free(q);
}

void imprime(tipofila fila){
	tipocelula *aux;
	aux = fila.frente->prox;
	while(aux != NULL){
		printf("%d\n", aux->chave);
		aux = aux->prox;
	}
}

void imprimefila(tipofila *fila){
	tipocelula aux;
	tipofila filaaux;
	ffvazia(&filaaux);
	while(!vazia(*fila)){
		desinfileira(fila, &aux);
		printf("%d\n", aux.chave);
		enfileira(aux.chave, &filaaux);
	}
	while(!vazia(filaaux)){
		desinfileira(&filaaux, &aux);
		enfileira(aux.chave, fila);
	}
}

void copiafila(tipofila *fila, tipofila *fila2){
	tipocelula aux;
	tipofila filaaux;
	ffvazia(&filaaux);
	while(!vazia(*fila)){
		desinfileira(fila, &aux);
		//printf("%d\n", aux.chave);
		enfileira(aux.chave, &filaaux);
		imprime(filaaux);
		printf("\n");
	}
	while(!vazia(filaaux)){
		desinfileira(&filaaux, &aux);
		enfileira(aux.chave, fila);
	}
	printf("\n\nnova fila");
	imprime(filaaux);
}

void insereordenado(int x, tipofila *fila){
	tipocelula aux;
	tipofila filaaux;
	ffvazia(&filaaux);
	
	if(vazia(*fila)){
		enfileira(x,fila);
	}
	else{
		while(!vazia(*fila)){
			desinfileira(fila,&aux);
			if(aux.chave > x){
				enfileira(aux.chave, &filaaux);
			}
			else{
				enfileira(x, &filaaux);
				enfileira(aux.chave, &filaaux);
				while(!vazia(*fila)){
					desinfileira(fila,&aux);
					enfileira(aux.chave, &filaaux);
				}
			}
		}	
		
		while(!vazia(filaaux)){
			desinfileira(&filaaux, &aux);
			enfileira(aux.chave, fila);
		}
		
	}

}


int main(){
	
	tipofila FILA, FILA2;	
	tipocelula X;
		
	ffvazia(&FILA);	
	
	insereordenado(10, &FILA);
	insereordenado(140, &FILA);
	insereordenado(130, &FILA);
	insereordenado(1880, &FILA);
	insereordenado(1, &FILA);
		
	imprime(FILA);
	
}
