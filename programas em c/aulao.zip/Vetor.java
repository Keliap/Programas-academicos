/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aulao;
import javax.swing.*;
import java.util.Scanner;
/**
 *
 * @author hackathon
 */
public class Vetor {

// Declarando e Inicializando um array de Aluno com capacidade 100.
    String saida,nome,menor="0";
    public String vet;
    public String auxvet;
    int contador, j;
    
  
  public void criaString() {
    // implementação
    
    System.out.println ("Digite uma palavra");
    Scanner scan = new Scanner (System.in);
    String vet = scan.nextLine();
    this.contador= vet.length();
  }
  public void percorre (String vet){
     for (int i = 0; i < contador; i++){
         int contador2 = 0;
         if (vet.charAt(i) == vet.charAt(i+1)){
            while (vet.charAt(i) == vet.charAt(i+1)){
             contador2 = contador2 + 1;
            }
            auxvet = auxvet + contador2;
            while (i != vet.length()){
                auxvet.charAt(i+1)= auxvet + vet.charAt(1);                      
            }
         
        }
    }
 }
}
